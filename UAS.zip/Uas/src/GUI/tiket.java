
package GUI;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.Statement;
import database.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class tiket extends javax.swing.JFrame {
    Connection conn=null;

    public tiket() {
        initComponents();
        conn=Database.getKoneksi();
        setLocationRelativeTo(null);
        tbtiket();
    }
    
    public void refresh(){
        ntiket.setText("");
        judul.setText("");
        waktu.setText("");
        harga.setText("");                
    }
    
public void tbtiket(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("no tiket");
        tbl.addColumn("judul");
        tbl.addColumn("waktu");
        tbl.addColumn("harga");               
        tbl.getDataVector().removeAllElements();
        tbl.fireTableDataChanged();
        
        try {
            String sql = "SELECT * FROM tiket";
            Connection con = (Connection) Database.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                    rs.getString("no_tiket"),                    
                    rs.getString("judul"),
                    rs.getString("waktu"),
                    rs.getString("harga"),                 
                });                
                tiket.setModel(tbl);                              
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
 }
  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        harga = new javax.swing.JTextField();
        judul = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tiket = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        waktu = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        ntiket = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        ubh = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tambah = new javax.swing.JLabel();
        keluar = new javax.swing.JLabel();
        hapus = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel3.setBackground(new java.awt.Color(63, 69, 75));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        harga.setBackground(new java.awt.Color(153, 153, 153));
        jPanel3.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 90, 130, -1));

        judul.setBackground(new java.awt.Color(153, 153, 153));
        judul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                judulActionPerformed(evt);
            }
        });
        jPanel3.add(judul, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 90, 100, -1));

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Judul");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 70, -1, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Harga");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, -1, -1));

        tiket.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "No Tiket", "Judul", "Waktu", "Harga"
            }
        ));
        tiket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tiketMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tiket);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 620, 350));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Waktu");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 70, -1, -1));

        waktu.setBackground(new java.awt.Color(153, 153, 153));
        waktu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                waktuActionPerformed(evt);
            }
        });
        jPanel3.add(waktu, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 90, 190, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("No Tiket");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, -1, -1));

        ntiket.setBackground(new java.awt.Color(153, 153, 153));
        ntiket.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ntiketActionPerformed(evt);
            }
        });
        jPanel3.add(ntiket, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 90, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/logok.png"))); // NOI18N
        jPanel3.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        ubh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/ubah.png"))); // NOI18N
        ubh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubhMouseClicked(evt);
            }
        });
        jPanel3.add(ubh, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 250, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Tiket.png"))); // NOI18N
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 10, -1, -1));

        tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Tambah.png"))); // NOI18N
        tambah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahMouseClicked(evt);
            }
        });
        jPanel3.add(tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 130, -1, -1));

        keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/keluar.png"))); // NOI18N
        keluar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                keluarMouseClicked(evt);
            }
        });
        jPanel3.add(keluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 430, -1, -1));

        hapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Hapus.png"))); // NOI18N
        hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusMouseClicked(evt);
            }
        });
        jPanel3.add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 190, -1, -1));

        jMenu1.setText("Pelanggan");
        jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu1MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu1);

        jMenu2.setText("Tiket");
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 778, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 480, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void judulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_judulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_judulActionPerformed

    private void waktuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_waktuActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_waktuActionPerformed

    private void jMenu1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu1MouseClicked
        // TODO add your handling code here:
        dispose();
        pelanggan s= new pelanggan();
        s.setVisible(true);
    }//GEN-LAST:event_jMenu1MouseClicked

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        dispose();
        tiket s= new tiket();
        s.setVisible(true);
    }//GEN-LAST:event_jMenu2MouseClicked

    private void tiketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tiketMouseClicked
        // TODO add your handling code here:
        int baris = tiket.rowAtPoint(evt.getPoint());
        String a = tiket.getValueAt(baris, 0).toString();
        ntiket.setText(a);
        String nama = tiket.getValueAt(baris, 1).toString();
        judul.setText(nama);
        String almts = tiket.getValueAt(baris, 2).toString();
        waktu.setText(almts);
        String telp = tiket.getValueAt(baris, 3).toString();
        harga.setText(telp);
            
    }//GEN-LAST:event_tiketMouseClicked

    private void ntiketActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ntiketActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ntiketActionPerformed

    private void ubhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubhMouseClicked
        // TODO add your handling code here:
        try {
            String sql = "UPDATE tiket SET no_tiket='"+ntiket.getText()+"',judul ='"+judul.getText()
                    +"',waktu ='"+waktu.getText()+"',harga ='"+harga.getText()+"'WHERE no_tiket='"+ntiket.getText()+"'";
                    
            Connection con = (Connection) Database.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);  
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil megubah data admin");
            tbtiket();
            refresh();
          } catch (Exception e) {        
    }        
    }//GEN-LAST:event_ubhMouseClicked

    private void tambahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahMouseClicked
        // TODO add your handling code here:
        try {           
           PreparedStatement stmt = conn.prepareStatement("INSERT INTO tiket (no_tiket,judul, waktu,  harga) values (?,?,?,?)");
            stmt.setString(1, ntiket.getText());           
            stmt.setString(2, judul.getText());
            stmt.setString(3, waktu.getText());
            stmt.setString(4,harga.getText());                   
            stmt.executeUpdate();
            
            JOptionPane.showMessageDialog(null, "Data berhasil disimpan", "Pesan", JOptionPane.INFORMATION_MESSAGE);
            tbtiket();
            refresh();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
        }        
    }//GEN-LAST:event_tambahMouseClicked

    private void keluarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_keluarMouseClicked
        // TODO add your handling code here:
          int jawab = JOptionPane.showOptionDialog(this,
                "Ingin Keluar?",
                "Keluar",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, null, null);

        if (jawab == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Program Akan Keluar");
            System.exit(0);
        }
    }//GEN-LAST:event_keluarMouseClicked

    private void hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusMouseClicked
        // TODO add your handling code here:
         try {
            String sql = "DELETE FROM tiket WHERE no_tiket =' " + ntiket.getText() + " ' ";
            Connection con = (Connection) Database.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil menghapus data");
            tbtiket();
            dispose();
            tiket s= new tiket();
             s.setVisible(true);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_hapusMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(tiket.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new tiket().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel hapus;
    private javax.swing.JTextField harga;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField judul;
    private javax.swing.JLabel keluar;
    private javax.swing.JTextField ntiket;
    private javax.swing.JLabel tambah;
    private javax.swing.JTable tiket;
    private javax.swing.JLabel ubh;
    private javax.swing.JTextField waktu;
    // End of variables declaration//GEN-END:variables
}