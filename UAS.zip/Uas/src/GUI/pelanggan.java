
package GUI;
import database.Database;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class pelanggan extends javax.swing.JFrame {
    Connection conn=null;
    ResultSet rs=null;
    PreparedStatement pst=null;
    int curRow=0;

    public pelanggan() {
        initComponents();
        conn=Database.getKoneksi();
        setLocationRelativeTo(null);
        tabel();
        tbpl();        
    }
    
    public void refresh(){
        id.setText("");
        tkt.setText("");
        judul.setSelectedItem("");                
    }

    public void tabel(){
        DefaultTableModel tbl = new DefaultTableModel();             
        tbl.addColumn("judul");
        tbl.getDataVector().removeAllElements();
        tbl.fireTableDataChanged();
        try {
            String sql = "SELECT * FROM tiket";
            Connection con = (Connection) Database.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {                
                rs.getString("judul"),
                });                            
              judul.addItem(rs.getString("judul"));                
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    public void tbpl(){
        DefaultTableModel tbl = new DefaultTableModel();
        tbl.addColumn("id");
        tbl.addColumn("no_tiket");
        tbl.addColumn("nama");
        tbl.addColumn("judul");
        tbl.addColumn("waktu");            
        tbl.getDataVector().removeAllElements();
        tbl.fireTableDataChanged();
        
        try {
            String sql = "SELECT * FROM pelanggan INNER JOIN tiket using(no_tiket)";
            Connection con = (Connection) Database.getKoneksi();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            
            while(rs.next()){
                tbl.addRow(new Object[] {
                    rs.getString("id"),
                    rs.getString("no_tiket"),                    
                    rs.getString("nama"),
                    rs.getString("judul"),
                    rs.getString("waktu"),                                      
                });                             
                tb.setModel(tbl);                              
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        judul = new javax.swing.JComboBox<>();
        id = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        tkt = new javax.swing.JLabel();
        keluar = new javax.swing.JLabel();
        hapus = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tambah = new javax.swing.JLabel();
        ubh = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        pelanggan = new javax.swing.JMenu();
        tiket = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(63, 69, 75));

        jPanel3.setBackground(new java.awt.Color(63, 69, 75));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("No Tiket");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 50, -1));

        tb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID", "No Tiket", "Nama", "Judul", "Waktu"
            }
        ));
        tb.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tb);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 660, 330));

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Judul");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, -1, -1));

        judul.setBackground(new java.awt.Color(153, 153, 153));
        judul.addPopupMenuListener(new javax.swing.event.PopupMenuListener() {
            public void popupMenuCanceled(javax.swing.event.PopupMenuEvent evt) {
            }
            public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {
                judulPopupMenuWillBecomeInvisible(evt);
            }
            public void popupMenuWillBecomeVisible(javax.swing.event.PopupMenuEvent evt) {
            }
        });
        judul.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                judulMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                judulMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                judulMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                judulMouseReleased(evt);
            }
        });
        jPanel3.add(judul, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 120, 160, -1));

        id.setBackground(new java.awt.Color(153, 153, 153));
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        jPanel3.add(id, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 90, -1));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("ID");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, -1));

        nama.setBackground(new java.awt.Color(153, 153, 153));
        nama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                namaActionPerformed(evt);
            }
        });
        jPanel3.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 120, 120, -1));

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nama");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 100, -1, -1));

        tkt.setForeground(new java.awt.Color(255, 255, 255));
        tkt.setText("-");
        jPanel3.add(tkt, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 120, 10, -1));

        keluar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/keluar.png"))); // NOI18N
        keluar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                keluarMouseClicked(evt);
            }
        });
        jPanel3.add(keluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, -1, -1));

        hapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Hapus.png"))); // NOI18N
        hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hapusMouseClicked(evt);
            }
        });
        jPanel3.add(hapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 230, -1, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/logok.png"))); // NOI18N
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        tambah.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Tambah.png"))); // NOI18N
        tambah.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tambahMouseClicked(evt);
            }
        });
        jPanel3.add(tambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 160, -1, -1));

        ubh.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/ubah.png"))); // NOI18N
        ubh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ubhMouseClicked(evt);
            }
        });
        jPanel3.add(ubh, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 300, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gambar/Pleangg.png"))); // NOI18N
        jPanel3.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 10, -1, -1));

        pelanggan.setText("Pelanggan");
        pelanggan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pelangganMouseClicked(evt);
            }
        });
        jMenuBar1.add(pelanggan);

        tiket.setText("Tiket");
        tiket.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tiketMouseClicked(evt);
            }
        });
        jMenuBar1.add(tiket);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 838, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pelangganMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pelangganMouseClicked
        // TODO add your handling code here:
           dispose();
           pelanggan s= new pelanggan();
           s.setVisible(true);
    }//GEN-LAST:event_pelangganMouseClicked

    private void tiketMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tiketMouseClicked
        // TODO add your handling code here:
        dispose();
        tiket s= new tiket();
        s.setVisible(true);
        
    }//GEN-LAST:event_tiketMouseClicked

    private void judulMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_judulMouseClicked
        // TODO add your handling code here:
        String item = (String) judul.getSelectedItem();
        String sql = "select * from tiket where judul = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, item);
            rs = pst.executeQuery();
                                          
          if(rs.next()){                      
            String nam = rs.getString("no_tiket");
            tkt.setText(nam);                
          }                      
          
        } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_judulMouseClicked

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void tbMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbMouseClicked
        // TODO add your handling code here:
        int baris = tb.rowAtPoint(evt.getPoint());
        String a = tb.getValueAt(baris, 0).toString();
        id.setText(a);
        String b = tb.getValueAt(baris, 1).toString();
        tkt.setText(b);
        String d = tb.getValueAt(baris, 2).toString();
        nama.setText(d);
        String c = tb.getValueAt(baris, 3).toString();
        judul.setSelectedItem(c);
        
    }//GEN-LAST:event_tbMouseClicked

    private void judulMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_judulMousePressed
        // TODO add your handling code here:
    }//GEN-LAST:event_judulMousePressed

    private void namaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_namaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_namaActionPerformed

    private void keluarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_keluarMouseClicked
        // TODO add your handling code here:
        int jawab = JOptionPane.showOptionDialog(this,
                "Ingin Keluar?",
                "Keluar",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, null, null);

        if (jawab == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(this, "Program Akan Keluar");
            System.exit(0);
        }
    }//GEN-LAST:event_keluarMouseClicked

    private void tambahMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tambahMouseClicked
        // TODO add your handling code here:
        try {
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pelanggan (id,no_tiket,nama) values (?,?,?)");
            stmt.setString(1, id.getText());
            stmt.setString(2, tkt.getText());
            stmt.setString(3, nama.getText());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Data berhasil disimpan", "Pesan", JOptionPane.INFORMATION_MESSAGE);
            tbpl();
            refresh();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Gagal Menambahkan" + e.getMessage());
        }        
    }//GEN-LAST:event_tambahMouseClicked

    private void hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hapusMouseClicked
        // TODO add your handling code here:
         try {
            String sql = "DELETE FROM pelanggan WHERE id =' " + id.getText() + " ' ";
            Connection con = (Connection) Database.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();

            JOptionPane.showMessageDialog(null, "Berhasil menghapus data");
            tabel();
            dispose();
            pelanggan s= new pelanggan();
            s.setVisible(true);
        } catch (Exception e) {
        }
    }//GEN-LAST:event_hapusMouseClicked

    private void ubhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ubhMouseClicked
        // TODO add your handling code here:
          try {
            String sql = "UPDATE pelanggan SET id='"+id.getText()+"',nama='"+nama.getText()
            +"',no_tiket='"+tkt.getText()+"'WHERE id='"+id.getText()+"'";

            Connection con = (Connection) Database.getKoneksi();
            PreparedStatement pst = con.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Berhasil megubah data");
            tbpl();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_ubhMouseClicked

    private void judulMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_judulMouseReleased
      
    }//GEN-LAST:event_judulMouseReleased

    private void judulMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_judulMouseExited
        // TODO add your handling code here:
       
    }//GEN-LAST:event_judulMouseExited

    private void judulPopupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent evt) {//GEN-FIRST:event_judulPopupMenuWillBecomeInvisible
       
        String item = (String) judul.getSelectedItem();
        String sql = "select * from tiket where judul = ?";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, item);
            rs =pst.executeQuery();
            
          if(rs.next()){               
            String nm = rs.getString("no_tiket");
            tkt.setText(nm);                              
          }
                                   
        } catch (Exception e) {
              JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_judulPopupMenuWillBecomeInvisible

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(pelanggan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(pelanggan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(pelanggan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(pelanggan.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new pelanggan().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel hapus;
    private javax.swing.JTextField id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JComboBox<String> judul;
    private javax.swing.JLabel keluar;
    private javax.swing.JTextField nama;
    private javax.swing.JMenu pelanggan;
    private javax.swing.JLabel tambah;
    private javax.swing.JTable tb;
    private javax.swing.JMenu tiket;
    private javax.swing.JLabel tkt;
    private javax.swing.JLabel ubh;
    // End of variables declaration//GEN-END:variables
}